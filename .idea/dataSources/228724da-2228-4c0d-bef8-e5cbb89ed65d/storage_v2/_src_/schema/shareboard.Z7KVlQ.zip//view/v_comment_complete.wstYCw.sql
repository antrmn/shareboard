create definer = root@localhost view v_comment_complete as
select `shareboard`.`comment`.`id`                AS `id`,
       `shareboard`.`comment`.`content`           AS `content`,
       `shareboard`.`comment`.`creation_date`     AS `creation_date`,
       `shareboard`.`comment`.`author_id`         AS `author_id`,
       `shareboard`.`comment`.`parent_comment_id` AS `parent_comment_id`,
       `shareboard`.`comment`.`post_id`           AS `post_id`,
       ifnull(`v`.`sum_votes`, 0)                 AS `votes`,
       `shareboard`.`post`.`title`                AS `post_title`,
       `shareboard`.`user`.`username`             AS `author_username`,
       (`a`.`user_id` is not null)                AS `is_admin`
from ((((`shareboard`.`comment` left join (select `shareboard`.`comment_vote`.`comment_id` AS `comment_id`,
                                                  sum(`shareboard`.`comment_vote`.`vote`)  AS `sum_votes`
                                           from `shareboard`.`comment_vote`
                                           group by `shareboard`.`comment_vote`.`comment_id`) `v` on ((`v`.`comment_id` = `shareboard`.`comment`.`id`))) join `shareboard`.`user` on ((`shareboard`.`comment`.`author_id` = `shareboard`.`user`.`id`))) left join `shareboard`.`admin` `a` on ((`a`.`user_id` = `shareboard`.`comment`.`author_id`)))
         join `shareboard`.`post` on ((`shareboard`.`comment`.`post_id` = `shareboard`.`post`.`id`)));

