create definer = root@localhost view v_user as
select `shareboard`.`user`.`id`            AS `id`,
       `shareboard`.`user`.`username`      AS `username`,
       `shareboard`.`user`.`password`      AS `password`,
       `shareboard`.`user`.`salt`          AS `salt`,
       `shareboard`.`user`.`email`         AS `email`,
       `shareboard`.`user`.`description`   AS `description`,
       `shareboard`.`user`.`picture`       AS `picture`,
       `shareboard`.`user`.`creation_date` AS `creation_date`,
       (`a`.`user_id` is not null)         AS `is_admin`
from (`shareboard`.`user`
         left join `shareboard`.`admin` `a` on ((`a`.`user_id` = `shareboard`.`user`.`id`)));

