create definer = root@localhost view v_comment as
select `shareboard`.`comment`.`id`                AS `id`,
       `shareboard`.`comment`.`content`           AS `content`,
       `shareboard`.`comment`.`creation_date`     AS `creation_date`,
       `shareboard`.`comment`.`author_id`         AS `author_id`,
       `shareboard`.`comment`.`parent_comment_id` AS `parent_comment_id`,
       `shareboard`.`comment`.`post_id`           AS `post_id`,
       ifnull(`v`.`sum_votes`, 0)                 AS `votes`
from (`shareboard`.`comment`
         left join (select `shareboard`.`comment_vote`.`comment_id` AS `comment_id`,
                           sum(`shareboard`.`comment_vote`.`vote`)  AS `sum_votes`
                    from `shareboard`.`comment_vote`
                    group by `shareboard`.`comment_vote`.`comment_id`) `v`
                   on ((`v`.`comment_id` = `shareboard`.`comment`.`id`)));

