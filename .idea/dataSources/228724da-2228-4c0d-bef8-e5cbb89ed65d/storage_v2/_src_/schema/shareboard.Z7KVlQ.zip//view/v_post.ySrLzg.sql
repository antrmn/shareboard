create definer = root@localhost view v_post as
select `shareboard`.`post`.`id`            AS `id`,
       `shareboard`.`post`.`title`         AS `title`,
       `shareboard`.`post`.`content`       AS `content`,
       `shareboard`.`post`.`type`          AS `type`,
       `shareboard`.`post`.`creation_date` AS `creation_date`,
       `shareboard`.`post`.`author_id`     AS `author_id`,
       `shareboard`.`post`.`section_id`    AS `section_id`,
       ifnull(`v`.`sum_votes`, 0)          AS `votes`,
       ifnull(`c`.`count_comments`, 0)     AS `n_comments`
from ((`shareboard`.`post` left join (select `shareboard`.`post_vote`.`post_id`   AS `post_id`,
                                             sum(`shareboard`.`post_vote`.`vote`) AS `sum_votes`
                                      from `shareboard`.`post_vote`
                                      group by `shareboard`.`post_vote`.`post_id`) `v` on ((`v`.`post_id` = `shareboard`.`post`.`id`)))
         left join (select count(`shareboard`.`comment`.`id`) AS `count_comments`,
                           `shareboard`.`comment`.`post_id`   AS `post_id`
                    from `shareboard`.`comment`
                    group by `shareboard`.`comment`.`post_id`) `c` on ((`c`.`post_id` = `shareboard`.`post`.`id`)));

